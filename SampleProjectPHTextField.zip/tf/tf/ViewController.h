//
//  ViewController.h
//  tf
//
//  Created by Mustafa Yazgülü on 26/01/2017.
//  Copyright © 2017 Mustafa Yazgülü. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PHTextField.h"

@interface ViewController : UIViewController

@property (nonatomic, weak) IBOutlet PHTextField *text;

@end

