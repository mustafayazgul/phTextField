//
//  ViewController.m
//  tf
//
//  Created by Mustafa Yazgülü on 26/01/2017.
//  Copyright © 2017 Mustafa Yazgülü. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    self.text.isKeyboardReturnKeyShouldDone = YES;
    [self.text initWithProperties:NO isTextFieldRounded:NO textFieldCornerRadius:0 textFieldBorderColor:[UIColor darkGrayColor] textFieldIConImage:nil textFieldPlaceHolder:@"Kullanici Adi" dropDownImage:nil];
    
    [self.text setBorderColor:[UIColor darkGrayColor]];
}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self.text hideKeyboard];
}

@end
