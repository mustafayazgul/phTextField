//
//  ViewController.m
//  tf
//
//  Created by Mustafa Yazgülü on 26/01/2017.
//  Copyright © 2017 Mustafa Yazgülü. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    self.text.isKeyboardReturnKeyShouldDone = YES;
    [self.text initWithProperties:NO isTextFieldRounded:NO textFieldCornerRadius:0 textFieldBorderColor:[UIColor darkGrayColor] textFieldIConImage:nil textFieldPlaceHolder:@"User Name" dropDownImage:nil];
    [self.text setBorderColor:[UIColor darkGrayColor]];
    
    [self.text1 initWithProperties:YES isTextFieldRounded:NO textFieldCornerRadius:0 textFieldBorderColor:[UIColor darkGrayColor] textFieldIConImage:[UIImage imageNamed:@"password"] textFieldPlaceHolder:@"Password" dropDownImage:nil];
    [self.text1 setBorderColor:[UIColor darkGrayColor]];
    
    self.text2.isDropDown = YES;
    [self.text2 initWithProperties:NO isTextFieldRounded:NO textFieldCornerRadius:0 textFieldBorderColor:[UIColor darkGrayColor] textFieldIConImage:nil textFieldPlaceHolder:@"Email" dropDownImage:[UIImage imageNamed:@"arrowdown_purple"]];
    [self.text2 setBorderColor:[UIColor darkGrayColor]];
}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self.text hideKeyboard];
}

@end
